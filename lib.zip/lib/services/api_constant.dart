class ApiConstant {
  static String baseUrl = 'https://api.maharstg.com'; //demo
  static String display = '/display/v1/';
  static String content = '/content/v1/';
  static String profile = '/profile/v1/';
  static String playerUrl = 'https://player.maharstg.com/player/v1?';
}
