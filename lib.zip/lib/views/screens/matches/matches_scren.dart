import 'package:flutter/material.dart';

class MatchesScren extends StatelessWidget {
  const MatchesScren({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Matches'),
          centerTitle: true,
        ),
        body: Container());
  }
}
